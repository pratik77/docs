/**
 * 
 */
function overlayEffect()
{
document.getElementById("overlay").style.display="block";	
return false;
}