package com.cg.tourist.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.tourist.dto.Place;
import com.cg.tourist.dto.User;
import com.cg.tourist.staticDB.StaticDB;

public class TouristDAO {

	StaticDB db=new StaticDB();
	public User checkLogin(String username,String password)
	{
		int userFlag=3;
		HashMap temphm=db.getUser();
		Set<String> set=temphm.entrySet();
		Iterator iterator=set.iterator();
		User user=new User();
		while(iterator.hasNext())
		{
			Map.Entry<String,User> me=(Map.Entry)iterator.next();
			if(me.getKey().equals(username))
			{
				user=me.getValue();
				if(password.equals(user.getPassword()))
					userFlag=user.getUserFlag();
				break;
			}
		}
		if (userFlag == 3) {
			return new User();
		} 


		return user;
	}
	public HashMap retrieveAllPlaces() {
		// TODO Auto-generated method stub
		return db.getPlaces();
		
		
	}
	public Place getPlaceByName(String name) {
		// TODO Auto-generated method stub
		HashMap temphm=db.getPlaces();
		Set<String> set=temphm.entrySet();
		Iterator iterator=set.iterator();
		while(iterator.hasNext())
		{
			Map.Entry<String,Place> me=(Map.Entry)iterator.next();
			if(me.getValue().getName().equals(name))
			{
				
				return me.getValue();
			}
		}
		return null;
	}
	public void updatePlace(Place place) {
		// TODO Auto-generated method stub
		HashMap temphm=db.getPlaces();
		Set<String> set=temphm.entrySet();
		Iterator iterator=set.iterator();
		while(iterator.hasNext())
		{
			Map.Entry<String,Place> me=(Map.Entry)iterator.next();
			System.out.println(me.getValue()+place.getName());
			if(me.getValue().getName().equals(place.getName()))
			{
				temphm.put(me.getKey(), place);
				StaticDB.places=temphm;
				
				System.out.println("In dao"+StaticDB.places);
			}
		}
		
	}
	public Place insertPlace(Place place) {
		// TODO Auto-generated method stub
		db.getPlaces().put(place.getName(), place);
		return place;
	}

}
