package com.cg.tourist.controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.tourist.dao.TouristDAO;
import com.cg.tourist.dto.Place;
import com.cg.tourist.dto.User;
import com.cg.tourist.staticDB.StaticDB;


@Controller
public class TouristController {
	TouristDAO dao = new TouristDAO();

	String userId="";
	String userFlag;
	String search="";
	User userGlobal;
	String message="";

	@RequestMapping(value = "/loginPage.obj")
	public String loginPage(Model model)
	{
		model.addAttribute("user",new User());
		model.addAttribute("tags",StaticDB.getTags());
		return "login";
	}
	@RequestMapping(value = "/login.obj")
	public String checkLogin(@RequestParam("username") String username,
			@RequestParam("password") String password, Model model) {

		userGlobal = dao.checkLogin(username, password);
		System.out.println(userGlobal.getUsername());
		model.addAttribute("userId", userId);
		if (userGlobal.getUsername()==null)
		{
			message="Invalid user ID and password combination.";
			model.addAttribute("message",message
					);
			message="";
			model.addAttribute("user",new User());
		return "login";
		}
		else if(userGlobal.getUserFlag()==1)
		{
			HashMap<String, Place> places = new HashMap();
			places = dao.retrieveAllPlaces();
			Set set = places.entrySet();
			Iterator it = set.iterator();
			Set<Place> values = new HashSet();
			userId = username;
			while (it.hasNext()) {
				Map.Entry<String, Place> me = (Map.Entry) it.next();
				Place placeTemp = new Place();
				placeTemp = me.getValue();
				values.add(placeTemp);
				System.out.println(placeTemp.getName());
			}
			model.addAttribute("places", values);
			model.addAttribute("place", new Place());
			model.addAttribute("userId", userId);
			return "allPlaces";
		}
		else
		{
			HashMap<String, Place> places = new HashMap();
			places = dao.retrieveAllPlaces();
			Set set = places.entrySet();
			Set<Place> values = new HashSet();
			userId = username;
			for(String tag:userGlobal.getTags())
			{
				Iterator it = set.iterator();
			while (it.hasNext()) {
				Map.Entry<String, Place> me = (Map.Entry) it.next();
				Place placeTemp = new Place();
				placeTemp = me.getValue();
				if(placeTemp.getTags().equals(tag))
				{
				values.add(placeTemp);
				System.out.println(placeTemp.getName());
				}
				}
				System.out.println(tag);
			}
			model.addAttribute("places", values);
			model.addAttribute("place", new Place());
			model.addAttribute("userId", userId);
		return "allPlacesUser";
		}
	}
	
	@RequestMapping(value = "/createAnAccount.obj")
	public String createAnAccount(Model model) {
		return "createAnAccount";
	}

	@RequestMapping(value = "/retrieveAllPlaces.obj")
	public String retrieveAllPlaces(Model model) {
		HashMap<String, Place> places = new HashMap();
		places = dao.retrieveAllPlaces();
		Set set = places.entrySet();
		Iterator it = set.iterator();
		Set<Place> values = new HashSet();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
		}
		model.addAttribute("places", values);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		if(userGlobal.getUserFlag()==1)
		return "allPlaces";
		places = new HashMap();
		places = dao.retrieveAllPlaces();
		set = places.entrySet();
		values = new HashSet();
		
		for(String tag:userGlobal.getTags())
		{
			it = set.iterator();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			if(placeTemp.getTags().equals(tag))
			{
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
			}
			}
			System.out.println(tag);
		}
		model.addAttribute("places", values);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		return "allPlacesUser";

	}

	@RequestMapping(value = "/modifyOrDelete.obj")
	public String modifyAndDeletePlace(@RequestParam("submit") String submit,
			@RequestParam("placeObj") String name, Model model) {
		Place place=new Place();
		if (("modify").equals(submit)) {
			try {
				
				place.setName(name);
				place = dao.getPlaceByName(place.getName());
				
			} catch (Exception e) {
				model.addAttribute("message", e.getMessage());
				return "error";
			}
			model.addAttribute("place", place);
			model.addAttribute("areas",StaticDB.getAreas());
			model.addAttribute("userId", userId);
			return "modifyPlace";
		}
		else{
		Set<Place> values = new HashSet();
		try {
			HashMap temphm=new HashMap();
			temphm=StaticDB.getPlaces();
			Set set=temphm.entrySet();
			Iterator it = set.iterator();
			
			while (it.hasNext()) {
				Map.Entry<String, Place> me = (Map.Entry) it.next();
				if(me.getValue().getName().equals(name))
				{
				StaticDB.getPlaces().remove(me.getKey());
				}
				else
				{
					Place placeTemp=new Place();
					placeTemp=me.getValue();
					values.add(placeTemp);
					System.out.println("1");
				}
			}
			System.out.println("hi2");
			model.addAttribute("places", values);
			model.addAttribute("place", new Place());
			model.addAttribute("userId", userId);
			System.out.println("hi");
			return "allPlaces";
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		
		
		

		
	}
	}

	@RequestMapping(value = "/insertModifiedPlace.obj", method = RequestMethod.POST)
	public String modifyComposer(@ModelAttribute("place") Place place,
			Model model) {
		System.out.println("hi "+place.getArea());
		//System.out.println(place.getAddress());
		try {
			dao.updatePlace(place);
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		HashMap<String, Place> places = new HashMap();
		places = dao.retrieveAllPlaces();
		Set set = places.entrySet();
		Iterator it = set.iterator();
		Set<Place> values = new HashSet();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
		}
		model.addAttribute("places", values);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		//if(userGlobal.getUserFlag()==1)
		return "allPlaces";
	}

	@RequestMapping(value = "/addPlace.obj")
	public String addPlace(Model model) {
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		model.addAttribute("areas",StaticDB.getAreas());
		return "addPlace";
	}

	@RequestMapping(value = "/insertPlace.obj", method = RequestMethod.POST)
	public String insertPlace(@ModelAttribute("place") Place place, Model model) {
		try {
			Place placeTemp = dao.insertPlace(place);
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		model.addAttribute("message", "Place with name " + place.getName()
				+ " added successfully!");
		model.addAttribute("userId", userId);
		return "successPlace";
	}
	
	@RequestMapping(value = "/searchPlace.obj", method = RequestMethod.POST)
	public String searchPlace(@RequestParam("place") String place, Model model) {
		Set<Place> values = new HashSet();
		try {
			Set set=StaticDB.getPlaces().entrySet();
			Iterator it = set.iterator();
			
			while (it.hasNext()) {
				Map.Entry<String, Place> me = (Map.Entry) it.next();
				if(me.getValue().getName().toLowerCase().contains(place.toLowerCase()))
				{
				Place placeTemp=new Place();
				placeTemp=me.getValue();
				values.add(placeTemp);
				}
			}
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		
		search=place;
		model.addAttribute("search",search);
		search="";
		model.addAttribute("places", values);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		
		if(userGlobal.getUserFlag()==1)
			return "allPlaces";
		Set valueTemp=new HashSet();
		valueTemp=searchForUser(place);
		
		model.addAttribute("places", valueTemp);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
			return "allPlacesUser";
	}
	
	@RequestMapping(value = "/addUser.obj")
	public String artistSongAssoc(@ModelAttribute("user") User user,
			@RequestParam("tagSelect") String[] tags, Model model) {

		
			user.setUserFlag(2);
			for(String tag:tags)
			{
				user.getTags().add(tag);
				System.out.println(tag);
			}
		/*} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}*/
		StaticDB.getUser().put(user.getUsername(), user);
		model.addAttribute("message",
				"Hey "+user.getUsername()+"! you are registered successfully!");
		return "login";
	}
	
	private Set searchForUser(String place)
	{
		HashMap<String, Place> places = new HashMap();
		places = dao.retrieveAllPlaces();
		Set set = places.entrySet();
		Set<Place> values = new HashSet();
		
		for(String tag:userGlobal.getTags())
		{
			Iterator it = set.iterator();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			if(placeTemp.getTags().equals(tag))
			{
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
			}
			}
			System.out.println(tag);
		}
		Set valueTemp=new HashSet();
		for(Place placeTemp:values)
		{
			if(placeTemp.getName().toLowerCase().contains(place.toLowerCase()))
			{
			Place placeNew=new Place();
			placeNew=placeTemp;
			valueTemp.add(placeNew);
			}
		}
			return valueTemp;
	}
}
